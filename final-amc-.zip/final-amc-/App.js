import React from 'react';
import { View, StyleSheet } from 'react-native';
import VCard from './VCard';

const App = () => {
  return (
    <View style={styles.container}>
      <VCard 
        name="Ortega, Arjay"
        occupation="Electrical Engineer"
        email="arjayortega09@gmail.com"
        contactNo="09274124312"
        dob="January 9, 2001"
        location="Tanza 2 Navotas City"
        profilePic={require('./vcardpic.jpg')}
        coverPhoto={require('./electrical.gif')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    color: '#fff',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
});

export default App;
